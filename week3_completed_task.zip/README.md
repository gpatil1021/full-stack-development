# Week 3 – Full Stack Task Manager

A complete MERN-style Week 3 submission covering:
- Express REST API and MongoDB/Mongoose
- User registration/login with JWT
- Task CRUD and filtering
- React + Axios frontend integration
- React Router protected dashboard
- Context API authentication state
- Multer image upload and image preview/display
- Postman-ready backend endpoints

## Requirements
Node.js 18+, MongoDB local or MongoDB Atlas.

## Run backend
1. `cd backend`
2. `npm install`
3. Copy `.env.example` to `.env` and set `MONGO_URI` and `JWT_SECRET`.
4. `npm run dev` (or `npm start`)

Backend runs at `http://localhost:5000`.

## Run frontend
1. Open another terminal.
2. `cd frontend`
3. `npm install`
4. `npm run dev`
5. Open the Vite URL shown in the terminal (normally `http://localhost:5173`).

## Main API routes
POST `/api/auth/register`
POST `/api/auth/login`
GET `/api/auth/me` (Bearer token)
GET `/api/tasks?status=all|pending|in-progress|completed` (Bearer token)
POST `/api/tasks` (Bearer token)
PUT `/api/tasks/:id` (Bearer token)
DELETE `/api/tasks/:id` (Bearer token)
POST `/api/upload` with multipart field `image` (Bearer token)

## Postman testing
Register or login first, copy the returned token, then use:
`Authorization: Bearer <token>`

For task creation, send JSON such as:
`{"title":"Learn React","description":"Connect frontend and backend","status":"pending"}`

For image upload, use Body → form-data → key `image` → type File.

## Notes
The upload folder is created in the backend and served at `/uploads`.
For deployment, set `VITE_API_URL` to the deployed backend API URL and replace the hard-coded image host in Dashboard.jsx with the same backend base URL.
