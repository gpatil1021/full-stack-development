require("dotenv").config();
const express=require("express");
const cors=require("cors");
const mongoose=require("mongoose");
const path=require("path");
const authRoutes=require("./routes/auth");
const taskRoutes=require("./routes/tasks");
const uploadRoutes=require("./routes/upload");

const app=express();
app.use(cors());
app.use(express.json());
app.use("/uploads",express.static(path.join(__dirname,"uploads")));
app.get("/",(req,res)=>res.json({message:"Week 3 Task Manager API is running"}));
app.use("/api/auth",authRoutes);
app.use("/api/tasks",taskRoutes);
app.use("/api/upload",uploadRoutes);

const PORT=process.env.PORT||5000;
mongoose.connect(process.env.MONGO_URI)
 .then(()=>app.listen(PORT,()=>console.log(`Server running on http://localhost:${PORT}`)))
 .catch(err=>{console.error("MongoDB connection failed:",err.message);process.exit(1);});
