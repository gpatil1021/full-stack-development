const jwt=require("jsonwebtoken");
const User=require("../models/User");
module.exports=async(req,res,next)=>{
  try{
    const header=req.headers.authorization;
    if(!header||!header.startsWith("Bearer ")) return res.status(401).json({message:"Authentication required"});
    const decoded=jwt.verify(header.split(" ")[1],process.env.JWT_SECRET);
    req.user=await User.findById(decoded.id).select("-password");
    if(!req.user) return res.status(401).json({message:"User not found"});
    next();
  }catch(e){res.status(401).json({message:"Invalid or expired token"});}
};
