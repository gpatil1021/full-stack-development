const router=require("express").Router();
const bcrypt=require("bcryptjs");
const jwt=require("jsonwebtoken");
const User=require("../models/User");
const auth=require("../middleware/auth");
const token=u=>jwt.sign({id:u._id},process.env.JWT_SECRET,{expiresIn:"7d"});

router.post("/register",async(req,res)=>{
 try{
  const {name,email,password}=req.body;
  if(!name||!email||!password) return res.status(400).json({message:"All fields are required"});
  if(password.length<6) return res.status(400).json({message:"Password must be at least 6 characters"});
  if(await User.findOne({email})) return res.status(409).json({message:"Email already registered"});
  const user=await User.create({name,email,password:await bcrypt.hash(password,10)});
  res.status(201).json({token:token(user),user:{id:user._id,name:user.name,email:user.email}});
 }catch(e){res.status(500).json({message:e.message});}
});
router.post("/login",async(req,res)=>{
 try{
  const {email,password}=req.body; const user=await User.findOne({email});
  if(!user||!(await bcrypt.compare(password,user.password))) return res.status(401).json({message:"Invalid email or password"});
  res.json({token:token(user),user:{id:user._id,name:user.name,email:user.email}});
 }catch(e){res.status(500).json({message:e.message});}
});
router.get("/me",auth,(req,res)=>res.json(req.user));
module.exports=router;
