const router=require("express").Router();
const Task=require("../models/Task");
const auth=require("../middleware/auth");

router.get("/",auth,async(req,res)=>{
 try{
  const filter={user:req.user._id};
  if(req.query.status&&req.query.status!=="all") filter.status=req.query.status;
  const tasks=await Task.find(filter).sort({createdAt:-1});
  res.json(tasks);
 }catch(e){res.status(500).json({message:e.message});}
});
router.post("/",auth,async(req,res)=>{
 try{const task=await Task.create({...req.body,user:req.user._id});res.status(201).json(task);}
 catch(e){res.status(400).json({message:e.message});}
});
router.put("/:id",auth,async(req,res)=>{
 try{
  const task=await Task.findOneAndUpdate({_id:req.params.id,user:req.user._id},req.body,{new:true,runValidators:true});
  if(!task)return res.status(404).json({message:"Task not found"});
  res.json(task);
 }catch(e){res.status(400).json({message:e.message});}
});
router.delete("/:id",auth,async(req,res)=>{
 try{
  const task=await Task.findOneAndDelete({_id:req.params.id,user:req.user._id});
  if(!task)return res.status(404).json({message:"Task not found"});
  res.json({message:"Task deleted"});
 }catch(e){res.status(500).json({message:e.message});}
});
module.exports=router;
