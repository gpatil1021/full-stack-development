const router=require("express").Router();
const multer=require("multer");
const path=require("path");
const auth=require("../middleware/auth");
const storage=multer.diskStorage({
 destination:(req,file,cb)=>cb(null,path.join(__dirname,"../uploads")),
 filename:(req,file,cb)=>cb(null,Date.now()+"-"+file.originalname.replace(/[^a-zA-Z0-9._-]/g,"_"))
});
const upload=multer({storage,limits:{fileSize:5*1024*1024},fileFilter:(req,file,cb)=>{
 const ok=/^image\/(jpeg|png|gif|webp)$/.test(file.mimetype);
 cb(ok?null:new Error("Only image files are allowed"),ok);
}});
router.post("/",auth,upload.single("image"),(req,res)=>{
 if(!req.file)return res.status(400).json({message:"No image uploaded"});
 res.status(201).json({url:`/uploads/${req.file.filename}`});
});
module.exports=router;
