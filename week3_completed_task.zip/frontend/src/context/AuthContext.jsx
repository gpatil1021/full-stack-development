import React,{createContext,useContext,useEffect,useState}from"react";import api from"../api";
const C=createContext();
export const AuthProvider=({children})=>{const[user,setUser]=useState(null);const[loading,setLoading]=useState(true);
 useEffect(()=>{if(localStorage.getItem("token"))api.get("/auth/me").then(r=>setUser(r.data)).catch(()=>localStorage.removeItem("token")).finally(()=>setLoading(false));else setLoading(false)},[]);
 const login=async(data)=>{const r=await api.post("/auth/login",data);localStorage.setItem("token",r.data.token);setUser(r.data.user)};
 const register=async(data)=>{const r=await api.post("/auth/register",data);localStorage.setItem("token",r.data.token);setUser(r.data.user)};
 const logout=()=>{localStorage.removeItem("token");setUser(null)};
 return <C.Provider value={{user,loading,login,register,logout}}>{children}</C.Provider>};
export const useAuth=()=>useContext(C);
