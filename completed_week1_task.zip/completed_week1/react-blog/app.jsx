const {useEffect,useMemo,useState}=React;
function PostCard({post}){return <article className="post"><span className="tag">{post.category}</span><h2>{post.title}</h2><p>{post.excerpt}</p><a href="#read">Read more →</a></article>}
function App(){const [posts,setPosts]=useState([]),[query,setQuery]=useState(''),[category,setCategory]=useState('All');
useEffect(()=>{fetch('posts.json').then(r=>r.json()).then(setPosts).catch(()=>setPosts([]))},[]);
const categories=['All',...new Set(posts.map(p=>p.category))];
const filtered=useMemo(()=>posts.filter(p=>(category==='All'||p.category===category)&&p.title.toLowerCase().includes(query.toLowerCase())),[posts,query,category]);
return <div className="app"><header className="hero"><h1>React Blog UI</h1><p>Search and filter posts loaded from JSON.</p></header><div className="controls"><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search posts..."/><select value={category} onChange={e=>setCategory(e.target.value)}>{categories.map(c=><option key={c}>{c}</option>)}</select></div><main className="posts">{filtered.length?filtered.map(p=><PostCard key={p.id} post={p}/>):<p>No posts found.</p>}</main></div>}
ReactDOM.createRoot(document.getElementById('root')).render(<App/>);