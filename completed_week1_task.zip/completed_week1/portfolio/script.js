const menuBtn=document.querySelector('.menu-btn');const nav=document.querySelector('.nav-links');menuBtn.addEventListener('click',()=>nav.classList.toggle('open'));
const form=document.getElementById('contactForm');form.addEventListener('submit',e=>{e.preventDefault();document.querySelectorAll('small').forEach(x=>x.textContent='');document.getElementById('success').textContent='';
let ok=true;const name=document.getElementById('name').value.trim(),email=document.getElementById('email').value.trim(),message=document.getElementById('message').value.trim();
if(name.length<2){document.getElementById('nameError').textContent='Please enter your name.';ok=false}
if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)){document.getElementById('emailError').textContent='Enter a valid email.';ok=false}
if(message.length<10){document.getElementById('messageError').textContent='Message must be at least 10 characters.';ok=false}
if(ok){document.getElementById('success').textContent='Message submitted successfully!';form.reset()}});