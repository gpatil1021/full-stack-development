const {useState}=React;
function Header(){return <header><h1>React Components Practice</h1><p>Reusable components using props and state.</p></header>}
function Footer(){return <footer>© 2026 React Practice</footer>}
function Card({title,description}){return <article className="card"><h3>{title}</h3><p>{description}</p></article>}
function Button({children,onClick}){return <button className="btn" onClick={onClick}>{children}</button>}
function Form({onAdd}){const [text,setText]=useState('');return <form onSubmit={e=>{e.preventDefault();if(text.trim()){onAdd(text.trim());setText('')}}}><input value={text} onChange={e=>setText(e.target.value)} placeholder="Enter a new skill"/> <Button>Add</Button></form>}
function App(){const [skills,setSkills]=useState(['HTML & CSS','JavaScript','React']);return <div className="wrap"><Header/><h2>Skills ({skills.length})</h2><div className="cards">{skills.map((s,i)=><Card key={i} title={s} description="Reusable React card component." />)}</div><p><Button onClick={()=>setSkills([...skills,'Node.js'])}>Add Node.js</Button></p><Form onAdd={s=>setSkills([...skills,s])}/><Footer/></div>}
ReactDOM.createRoot(document.getElementById('root')).render(<App/>);