# Week 1 – Frontend Fundamentals Completed

## Included tasks
1. `portfolio/` – responsive personal portfolio with About, Education, Projects, Contact, responsive navigation, Flexbox/Grid and JavaScript form validation.
2. `ecommerce-landing/` – responsive e-commerce landing page using CSS Grid.
3. `react-components/` – Header, Footer, Card, Button and Form reusable React components using props and state.
4. `react-blog/` – React blog UI loading posts from `posts.json`, with search and category filtering.

## How to run
- Portfolio and e-commerce: open `index.html` directly in a browser.
- React examples: for best results run a local server from the project folder, for example `python -m http.server 8000`, then open the displayed localhost URL.
- React examples use React/Babel from CDN, so an internet connection is needed.
