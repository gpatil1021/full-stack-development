import React,{useState} from 'react';
import {createRoot} from 'react-dom/client';
import {BrowserRouter,Routes,Route,Link} from 'react-router-dom';
import styles from './styles/App.module.css';

function Product({name,price,category}){return <article className={styles.card}><h3>{name}</h3><p>{category}</p><strong>₹{price}</strong></article>}
function Todo(){const [text,setText]=useState('');const [items,setItems]=useState([]);const add=()=>{if(text.trim()){setItems([...items,{id:Date.now(),text:text.trim()}]);setText('')}};return <section><h2>React To-Do</h2><div className={styles.row}><input value={text} onChange={e=>setText(e.target.value)} placeholder="Add task"/><button onClick={add}>Add</button></div><ul>{items.map(i=><li key={i.id}>{i.text}<button onClick={()=>setItems(items.filter(x=>x.id!==i.id))}>Delete</button></li>)}</ul></section>}
function Home(){return <><h1>Week 2 React Fundamentals</h1><p>Props, state, routing and CSS Modules.</p><div className={styles.grid}><Product name="Wireless Headphones" price="1499" category="Electronics"/><Product name="Smart Watch" price="2299" category="Wearables"/></div><Todo/></>}
function About(){return <><h1>About</h1><p>This page demonstrates React Router navigation.</p></>}
function App(){return <div className={styles.app}><nav><Link to="/">Home</Link><Link to="/about">About</Link></nav><main><Routes><Route path="/" element={<Home/>}/><Route path="/about" element={<About/>}/></Routes></main></div>}
createRoot(document.getElementById('root')).render(<BrowserRouter><App/></BrowserRouter>);
