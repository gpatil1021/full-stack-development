# Week 2 – Full Stack Web Development (MERN)

This project completes the Week 2 practice questions, assignments, and mini project.

## Included
- React product component
- React props and state
- React To-Do app with add/delete
- React Router multi-page navigation
- CSS Modules
- Node.js + Express REST API
- MongoDB + Mongoose
- Todo CRUD API
- User registration/login with bcrypt + JWT
- Protected Notes CRUD API

## Backend setup
```bash
cd backend
npm install
cp .env.example .env
npm run dev
```

Set `MONGO_URI` in `.env`. The default API runs on `http://localhost:5000`.

## Frontend setup
```bash
cd frontend
npm install
npm run dev
```

The Vite app runs on the URL shown in the terminal, normally `http://localhost:5173`.

## API endpoints
- `POST /api/auth/register`
- `POST /api/auth/login`
- `GET /api/todos`
- `POST /api/todos`
- `PUT /api/todos/:id`
- `DELETE /api/todos/:id`
- `GET /api/notes` (JWT required)
- `POST /api/notes` (JWT required)
- `PUT /api/notes/:id` (JWT required)
- `DELETE /api/notes/:id` (JWT required)

Use `Authorization: Bearer <token>` for protected notes routes.
