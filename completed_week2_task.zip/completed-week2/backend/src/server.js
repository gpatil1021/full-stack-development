import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import mongoose from 'mongoose';
import authRoutes from './routes/authRoutes.js';
import todoRoutes from './routes/todoRoutes.js';
import noteRoutes from './routes/noteRoutes.js';

dotenv.config();
const app = express();
app.use(cors());
app.use(express.json());
app.get('/', (req,res)=>res.json({message:'Week 2 MERN API is running'}));
app.use('/api/auth', authRoutes);
app.use('/api/todos', todoRoutes);
app.use('/api/notes', noteRoutes);
app.use((err,req,res,next)=>{ console.error(err); res.status(err.status||500).json({message:err.message||'Server error'}); });

const PORT = process.env.PORT || 5000;
mongoose.connect(process.env.MONGO_URI)
  .then(()=>app.listen(PORT,()=>console.log(`Server running on http://localhost:${PORT}`)))
  .catch(err=>{console.error('MongoDB connection failed:',err.message); process.exit(1);});
