import Todo from '../models/Todo.js';
export async function list(req,res,next){try{res.json(await Todo.find().sort({createdAt:-1}));}catch(e){next(e);}}
export async function create(req,res,next){try{if(!req.body.title?.trim())return res.status(400).json({message:'Title is required'});res.status(201).json(await Todo.create({title:req.body.title.trim()}));}catch(e){next(e);}}
export async function update(req,res,next){try{const todo=await Todo.findByIdAndUpdate(req.params.id,{title:req.body.title,completed:req.body.completed},{new:true,runValidators:true});if(!todo)return res.status(404).json({message:'Task not found'});res.json(todo);}catch(e){next(e);}}
export async function remove(req,res,next){try{const todo=await Todo.findByIdAndDelete(req.params.id);if(!todo)return res.status(404).json({message:'Task not found'});res.json({message:'Task deleted'});}catch(e){next(e);}}
