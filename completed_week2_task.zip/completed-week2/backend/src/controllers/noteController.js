import Note from '../models/Note.js';
const own=(id,user)=>({ _id:id,user:user });
export async function list(req,res,next){try{res.json(await Note.find({user:req.user.id}).sort({updatedAt:-1}));}catch(e){next(e);}}
export async function create(req,res,next){try{const {title,content}=req.body;if(!title||!content)return res.status(400).json({message:'Title and content are required'});res.status(201).json(await Note.create({title,content,user:req.user.id}));}catch(e){next(e);}}
export async function update(req,res,next){try{const note=await Note.findOneAndUpdate(own(req.params.id,req.user.id),{title:req.body.title,content:req.body.content},{new:true,runValidators:true});if(!note)return res.status(404).json({message:'Note not found'});res.json(note);}catch(e){next(e);}}
export async function remove(req,res,next){try{const note=await Note.findOneAndDelete(own(req.params.id,req.user.id));if(!note)return res.status(404).json({message:'Note not found'});res.json({message:'Note deleted'});}catch(e){next(e);}}
