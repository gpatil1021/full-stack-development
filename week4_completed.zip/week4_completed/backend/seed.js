import 'dotenv/config'; import mongoose from 'mongoose'; import Product from './models/Product.js';
await mongoose.connect(process.env.MONGO_URI); await Product.deleteMany({}); await Product.insertMany([
{name:'Wireless Headphones',description:'Comfortable Bluetooth headphones with deep bass.',price:2499,image:'https://images.unsplash.com/photo-1505740420928-5e560c06d30e',category:'Electronics',stock:20},
{name:'Smart Watch',description:'Fitness tracking and notifications on your wrist.',price:3999,image:'https://images.unsplash.com/photo-1523275335684-37898b6baf30',category:'Electronics',stock:15},
{name:'Running Shoes',description:'Lightweight everyday running shoes.',price:2999,image:'https://images.unsplash.com/photo-1542291026-7eec264c27ff',category:'Fashion',stock:25},
{name:'Backpack',description:'Durable laptop backpack for college and travel.',price:1499,image:'https://images.unsplash.com/photo-1553062407-98eeb64c6a62',category:'Accessories',stock:30}]); console.log('Seeded'); await mongoose.disconnect();
