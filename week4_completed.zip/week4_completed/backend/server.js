import 'dotenv/config'; import express from 'express'; import cors from 'cors'; import mongoose from 'mongoose'; import authRoutes from './routes/auth.js'; import productRoutes from './routes/products.js'; import orderRoutes from './routes/orders.js';
const app=express();app.use(cors({origin:process.env.CLIENT_URL?.split(',')||'*'}));app.use(express.json());
app.get('/api/health',(req,res)=>res.json({status:'ok',message:'Week 4 MERN Shop API'}));app.use('/api/auth',authRoutes);app.use('/api/products',productRoutes);app.use('/api/orders',orderRoutes);
const port=process.env.PORT||5000; mongoose.connect(process.env.MONGO_URI).then(()=>app.listen(port,()=>console.log(`API running on ${port}`))).catch(e=>{console.error(e);process.exit(1)});
