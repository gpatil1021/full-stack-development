import express from 'express'; import Product from '../models/Product.js';
const r=express.Router();
r.get('/',async(req,res)=>{try{const q=req.query.q||'';const products=await Product.find({name:{$regex:q,$options:'i'}}).sort({createdAt:-1});res.json(products)}catch(e){res.status(500).json({message:e.message})}});
r.post('/',async(req,res)=>{try{res.status(201).json(await Product.create(req.body))}catch(e){res.status(400).json({message:e.message})}});
r.put('/:id',async(req,res)=>{try{const p=await Product.findByIdAndUpdate(req.params.id,req.body,{new:true,runValidators:true});res.json(p)}catch(e){res.status(400).json({message:e.message})}});
r.delete('/:id',async(req,res)=>{try{await Product.findByIdAndDelete(req.params.id);res.json({message:'Deleted'})}catch(e){res.status(400).json({message:e.message})}});
export default r;
