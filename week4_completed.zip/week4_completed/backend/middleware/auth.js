import jwt from 'jsonwebtoken';
export default function auth(req,res,next){const h=req.headers.authorization;if(!h?.startsWith('Bearer '))return res.status(401).json({message:'Authentication required'});try{req.user=jwt.verify(h.split(' ')[1],process.env.JWT_SECRET);next()}catch{return res.status(401).json({message:'Invalid or expired token'})}}
