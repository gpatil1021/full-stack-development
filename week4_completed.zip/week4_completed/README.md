# Week 4 – MERN Capstone: ShopEasy

A production-ready starter mini e-commerce application satisfying the Week 4 practice set: React + Node/Express integration, signup/login, products + cart, orders, and deployment documentation.

## Features
- React/Vite responsive frontend
- Express/Node REST API
- MongoDB Atlas + Mongoose
- JWT authentication and password hashing
- Product search/listing
- Shopping cart with localStorage persistence
- Protected order creation and order history
- Stock validation and stock decrement on checkout
- Vercel frontend + Render backend deployment guide
- Seed data for four products

## Folder structure
```text
week4_completed/
├── backend/
│   ├── middleware/auth.js
│   ├── models/{User,Product,Order}.js
│   ├── routes/{auth,products,orders}.js
│   ├── server.js
│   ├── seed.js
│   ├── package.json
│   └── .env.example
├── frontend/
│   ├── src/
│   │   ├── components/
│   │   ├── context/ShopContext.jsx
│   │   ├── pages/
│   │   ├── api.js
│   │   ├── App.jsx
│   │   ├── main.jsx
│   │   └── styles.css
│   ├── package.json
│   ├── index.html
│   └── .env.example
└── README.md
```

## Run locally
### 1. MongoDB Atlas
Create a free MongoDB Atlas cluster, database user, and allow your IP address. Copy the connection string.

### 2. Backend
```bash
cd backend
npm install
copy .env.example .env
```
Set `MONGO_URI`, `JWT_SECRET`, and `CLIENT_URL=http://localhost:5173` in `.env`.

Seed products:
```bash
npm run start
# in another terminal
node seed.js
```
For development use `npm run dev`.

### 3. Frontend
```bash
cd frontend
npm install
copy .env.example .env
npm run dev
```
Open the Vite URL shown in the terminal (normally http://localhost:5173).

## API endpoints
| Method | Endpoint | Purpose |
|---|---|---|
| GET | /api/health | Health check |
| POST | /api/auth/signup | Register |
| POST | /api/auth/login | Login |
| GET | /api/products | Product listing/search |
| POST | /api/products | Add product |
| PUT | /api/products/:id | Update product |
| DELETE | /api/products/:id | Delete product |
| POST | /api/orders | Create order (JWT) |
| GET | /api/orders/mine | Current user's orders (JWT) |

## Deployment
### Backend on Render
1. Push this project to GitHub.
2. Create a Render Web Service using the `backend` directory.
3. Build command: `npm install`.
4. Start command: `npm start`.
5. Add environment variables: `MONGO_URI`, `JWT_SECRET`, `CLIENT_URL` and optionally `PORT`.
6. Deploy and copy the Render API URL.

### Frontend on Vercel
1. Import the GitHub repository into Vercel.
2. Set the project root to `frontend`.
3. Build command: `npm run build`.
4. Output directory: `dist`.
5. Add `VITE_API_URL=https://YOUR-RENDER-URL.onrender.com/api`.
6. Deploy.
7. Update backend `CLIENT_URL` to the Vercel URL and redeploy backend.

### GitHub submission
```bash
git init
git add .
git commit -m "Week 4 MERN capstone"
git branch -M main
git remote add origin YOUR_GITHUB_REPOSITORY_URL
git push -u origin main
```

## Testing checklist
- [ ] Backend `/api/health` returns status `ok`.
- [ ] Signup creates a user.
- [ ] Login returns a JWT.
- [ ] Products load in React.
- [ ] Search filters products.
- [ ] Add/remove/update cart works.
- [ ] Checkout rejects unauthenticated users.
- [ ] Checkout creates an order and reduces stock.
- [ ] Order history loads after login.
- [ ] Frontend production build succeeds.
- [ ] Render backend and Vercel frontend communicate successfully.

## Notes
This project uses the **E-Commerce Web Application** option from the Week 4 capstone options. Admin product endpoints are included as a simple product-control API; add an admin role middleware before exposing those mutation endpoints publicly in a production deployment.
